insert into employee
values('E01', 'Smith', 'Clerk');

insert into employee
values('E02', 'Allen', 'Salesman');