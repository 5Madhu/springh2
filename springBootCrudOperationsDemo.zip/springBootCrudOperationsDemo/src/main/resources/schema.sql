create table employee
(
   empNo varchar(255) not null,
   empName varchar(255) not null,
   position varchar(255) not null,
   primary key(empNo)
);