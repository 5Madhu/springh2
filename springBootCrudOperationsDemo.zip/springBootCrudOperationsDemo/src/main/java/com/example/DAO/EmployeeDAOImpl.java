package com.example.DAO;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.DTO.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	private static final Map<String, Employee> empMap = new HashMap<String, Employee>();



	
	
	public Employee getEmployee(String empNo) {
		return jdbcTemplate.queryForObject("select * from employee t where t.empNo=?", new Object[] { empNo },
				new BeanPropertyRowMapper<Employee>(Employee.class));
	}

	public int addEmployee(Employee emp) {
		return jdbcTemplate.update("insert into employee (empNo, empName, position) " + "values(?,  ?, ?)",
				new Object[] { emp.getEmpNo(), emp.getEmpName(), emp.getPosition() });
	}

	public int updateEmployee(Employee emp) {
		return jdbcTemplate.update("update employee " + "  empName = ? " + " position = ?" + " where id = ?",
				new Object[] { emp.getEmpName(), emp.getPosition(), emp.getEmpNo() });
	}

	public void deleteEmployee(String empNo) {
		jdbcTemplate.update("delete from employee t where t.empNo =?", new Object[] { empNo });
	}

	public List<Employee> getAllEmployees() {
		return jdbcTemplate.query("select * from employee", new BeanPropertyRowMapper<Employee>(Employee.class));
	}

}
