package com.tcs.demo.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tcs.demo.model.Employee;

public interface EmployeeRepo extends CrudRepository<Employee, Integer>
{
	List<Employee> findByTech(String tech)
;
}
