package com.tcs.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.tcs.demo.dao.EmployeeRepo;
import com.tcs.demo.model.Employee;

@Controller
public class EmployeeController 
{
	@Autowired
	EmployeeRepo repo;
	
	@RequestMapping("/")
	public String home()
	{
		return "home.jsp";
	}
	
	@RequestMapping("/addEmployee")
	public String addEmployee(Employee emp)
	{
		repo.save(emp);
		return "home.jsp";
	}
	
	@RequestMapping("/getEmployee")
	public ModelAndView getEmployee(@RequestParam Integer EmployeeId)
	{
		ModelAndView mv=new ModelAndView("ShowEmployees.jsp");
	    Employee emp= repo.findById(EmployeeId).orElse(new Employee());
	    System.out.println(repo.findByTech("Java"));
	    mv.addObject(emp);
		return mv;
	}
	
}
